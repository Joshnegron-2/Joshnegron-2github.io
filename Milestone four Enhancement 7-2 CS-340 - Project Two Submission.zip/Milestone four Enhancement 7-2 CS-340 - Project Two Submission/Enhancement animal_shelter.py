from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        USER = 'aacuser'
        PASS = 'SNHU2025'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32507
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # C - Create
    def create(self, data):
        if data is not None and isinstance(data, dict):
            result = self.collection.insert_one(data)
            return True if result.acknowledged else False
        else:
            raise Exception("Nothing to save, because data parameter is empty or not a dictionary")

    # R - Read
    def read(self, query):
        try:
            result = self.collection.find(query) if query else self.collection.find({})
            return list(result)
        except Exception as e:
            print(f"Read error: {e}")
            return []

    # Enhancement: Filter rescue dogs directly in MongoDB
    def read_rescue_type(self, rescue_type):
        rescue_queries = {
            'Water Rescue': {'breed': {'$regex': 'Retriever|Labrador|Golden', '$options': 'i'}},
            'Mountain/Wilderness Rescue': {'breed': {'$regex': 'German Shepherd|Doberman|Rottweiler', '$options': 'i'}},
            'Disaster/Tracking': {'breed': {'$regex': 'Bloodhound|Beagle|German Shepherd', '$options': 'i'}}
        }

        if rescue_type in rescue_queries:
            try:
                return list(self.collection.find(rescue_queries[rescue_type]))
            except Exception as e:
                print(f"Read rescue type error: {e}")
                return []

        return list(self.collection.find({}))

    # U - Update
    def update(self, query, new_values):
        if query and new_values:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print(f"Update error: {e}")
                return 0
        else:
            raise Exception("Both query and new_values must be provided for update")

    # D - Delete
    def delete(self, query):
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Delete error: {e}")
                return 0
        else:
            raise Exception("Query must be provided for delete")